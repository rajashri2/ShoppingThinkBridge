﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShoppingBrigdeApi.Models
{

    public class ProductModel
    {
        public int ProductId { get; set; }
        public string P_Name { get; set; }
        public string Colour { get; set; }
        public string Dimensions { get; set; }
        public string Description { get; set; }
        public Nullable<int> Price { get; set; }
        public string ModelNo { get; set; }
        public string Storage { get; set; }
        public Nullable<int> Warrenty { get; set; }
        public string OperatingSystem { get; set; }
        public string Simtype { get; set; }
        public string Weight { get; set; }
        public string Camera { get; set; }
        public string Brand_Name { get; set; }
        public string SimType { get; set; }
        public byte[] Image { get; set; }
    }

    public class Bridge_GetProductDetails
    {
        public int ProductId { get; set; }
        public string P_Name { get; set; }
        public string Colour { get; set; }
        public string Dimensions { get; set; }
        public string Description { get; set; }
        public Nullable<int> Price { get; set; }
        public string ModelNo { get; set; }
        public string Storage { get; set; }
        public Nullable<int> Warrenty { get; set; }
        public string OperatingSystem { get; set; }
        public string SimType { get; set; }
        public string Weight { get; set; }
        public string Camera { get; set; }
        public Nullable<System.DateTime> EntryDate { get; set; }
        public Nullable<System.DateTime> ModifiedDate { get; set; }
        public string Brand_Name { get; set; }
        public byte[] Image { get; set; }
        public HttpPostedFileBase ImageFile { get; set; }
        public string Flag { get; set; }
    }

   
}