﻿using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using ShoppingBrigdeApi.BridgeDataModel;
using ShoppingBrigdeApi.Models;


namespace ShoppingBrigdeApi.Controllers
{
    public class ProductApiController : ApiController
    {

        //
        // GET: /ProductApi/

        NorthwindEntities entities;
        ObjectParameter Status;
        ObjectParameter Message;

        public ProductApiController()
        {
            entities = new NorthwindEntities();
            Status = new ObjectParameter("status", typeof(bool));
            Message = new ObjectParameter("message", typeof(string));
        }

        public List<Bridge_GetProductDetails_Result> GetProductDetails()
        {
            List<Bridge_GetProductDetails_Result> lstBridge_GetProductDetails_Result = new List<Bridge_GetProductDetails_Result>();
            lstBridge_GetProductDetails_Result = entities.Bridge_GetProductDetails().ToList();
            return lstBridge_GetProductDetails_Result;
        }

        public ResponseStatus AddEditProduct(Bridge_GetProductDetails model)
        {
            ResponseStatus response = new ResponseStatus();
            int result = entities.Bridge_InsertUpdateProductDetails(model.ProductId, model.P_Name, model.Colour, model.Dimensions,
                model.Description, model.Price,
                model.ModelNo, model.Storage, model.Warrenty, model.OperatingSystem, model.SimType,
                model.Weight, model.Camera, model.Brand_Name, model.Image, model.Flag, Status, Message);
            response = new ResponseStatus() { Status = Convert.ToBoolean(Status.Value), Message = Convert.ToString(Message.Value) };
            return response;
        }

    }
}
