﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using ShoppingBrigdeApi.BridgeDataModel;
using ShoppingBridgeApi.Models;
using System.Data.Objects;
using ShoppingBrigdeApi.Models;



namespace ShoppingBrigdeApi.Controllers
{
    public class AccountApiController : ApiController
    {
        NorthwindEntities entities;
        ObjectParameter Status;
        ObjectParameter Message;

        public AccountApiController()
        {
            entities = new NorthwindEntities();
            Status = new ObjectParameter("status", typeof(bool));
            Message = new ObjectParameter("message", typeof(string));
        }

        //[System.Web.Http.HttpGet]
        //public int IsUserExists(string UserName, string Password)
        //{
        //    var result = entities.Bridge_IsUserExists(UserName, Password).ToList().FirstOrDefault();
        //    return Convert.ToInt16(result);
        //}

        public ResponseStatus AddUser(AccountModel model)
        {
            ResponseStatus response = new ResponseStatus();
            int result = Convert.ToInt16(entities.Bridge_AddUser(model.FirstName, model.LastName, model.UserName, model.Password, model.ConfirmPassword, model.MobileNo, model.EmailID, Status
                , Message));
            response = new ResponseStatus() { Status = Convert.ToBoolean(Status.Value), Message = Convert.ToString(Message.Value) };
            return response;
        }

        [System.Web.Http.HttpGet]
        public Bridge_UserDetails_Result UserDetails(string UserName, string Password)
        {
            Bridge_UserDetails_Result obj = new Bridge_UserDetails_Result();
            obj = entities.Bridge_UserDetails(UserName, Password).ToList().FirstOrDefault();
            return obj;
        }


    }
}
