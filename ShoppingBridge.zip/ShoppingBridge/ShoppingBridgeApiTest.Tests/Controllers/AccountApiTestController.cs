﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ShoppingBrigdeApi.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace ShoppingBridgeApiTest.Tests.Controllers
{
    [TestClass]
    public class AccountApiTestController
    {
        [TestMethod]
        public void GetLogin_Test()
        {
            // Arrange
            string UserName = "admin";
            string password = "admin";
            AccountApiController controller = new AccountApiController();
            controller.Request = new HttpRequestMessage { RequestUri = new Uri("http://localhost/api/AccountApi/UserDetails") };
            controller.Configuration = new HttpConfiguration();
            controller.Configuration.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional });
            var response = controller.UserDetails(UserName, password);
            var result = controller.UserDetails(UserName, password) as ShoppingBrigdeApi.BridgeDataModel.Bridge_UserDetails_Result;

            // Assert
            Assert.IsTrue(result.UserName == UserName, "Passed");

        }
        [TestMethod]
        public void AddUser_Test()
        {
            // Arrange

            AccountApiController controller = new AccountApiController();
            ShoppingBridgeApi.Models.AccountModel res = new ShoppingBridgeApi.Models.AccountModel();
            res.UserID = 100;
            res.FirstName = "Raj";
            res.LastName = "Amrut";
            res.UserName = "Raj";
            res.Password = "Test";
            res.MobileNo = "1234";
            res.EmailID = "a@as.com";
            // string UserName = "admin";
            res.Password = "admin";
            controller.Request = new HttpRequestMessage { RequestUri = new Uri("http://localhost/api/AccountApi/AddUser") };
            controller.Configuration = new HttpConfiguration();
            controller.Configuration.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional });
            var response = controller.AddUser(res);
            var result = controller.AddUser(res) as ShoppingBrigdeApi.Models.ResponseStatus;

            // Assert
            Assert.IsTrue(result.Message == "User Created Successfully..", "Passed");

        }
    }
}
