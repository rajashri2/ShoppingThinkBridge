﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShoppingBridgeApi;
using ShoppingBrigdeApi.Controllers;
using ShoppingBrigdeApi.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System.Web.Http;

namespace ShoppingBridgeApiTest.Tests.Controllers
{
    [TestClass]
    public class ProductApiTestController
    {

        [TestMethod]
        public void GetProductDetails_Test()
        {
            // Arrange
            ProductApiController controller = new ProductApiController();
            controller.Request = new HttpRequestMessage { RequestUri = new Uri("http://localhost/api/ProductApi/GetProductDetails") };
            controller.Configuration = new HttpConfiguration();
            controller.Configuration.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional });
            var response = controller.GetProductDetails();
            var result = controller.GetProductDetails() as List<ShoppingBrigdeApi.BridgeDataModel.Bridge_GetProductDetails_Result>;

            // Assert
            Assert.IsTrue(result.Count >= 0, "Passed");
        }

        [TestMethod]
        public void AddEditProduct_Test()
        {
            // Arrange
            ProductModel model = new ProductModel();
           // model.ProductId = 
            ProductApiController controller = new ProductApiController();
            controller.Request = new HttpRequestMessage { RequestUri = new Uri("http://localhost/api/ProductApi/GetProductDetails") };
            controller.Configuration = new HttpConfiguration();
            controller.Configuration.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional });
            var response = controller.GetProductDetails();
            var result = controller.GetProductDetails() as List<ShoppingBrigdeApi.BridgeDataModel.Bridge_GetProductDetails_Result>;

            // Assert
            Assert.IsTrue(result.Count >= 0, "Passed");
        }


    }
}
