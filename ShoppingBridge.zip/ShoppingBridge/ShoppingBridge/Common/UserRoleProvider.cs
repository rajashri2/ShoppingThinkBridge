﻿using ShoppingBridgeWeb.Common;
using ShoppingBridgeWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace ShoppingBridgeWeb.Common
{
    public class UserRoleProvider : AuthorizeAttribute
    {
        public string Roles;
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            var authroisedUser = base.AuthorizeCore(httpContext);
            //if (authroisedUser)
            //{
            //check for the session values
            var loggedInuserInfo = httpContext.Session["LoggedUserInfo"] as AccountModel;
            if (loggedInuserInfo == null)
            {
                return false;
            }
            if (this.Roles != null)
            {

                if (loggedInuserInfo.Role == "admin")
                {
                    if (Roles == loggedInuserInfo.Role)
                    {
                        return true;
                    }
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    return true;
                }
            }
            else
            {

                return false;
            }
        }
        //else
        //{
        //    return false;
        //}

    }
}