﻿
$(document).ready(function () {
    $(".orspan").css("display", "none");
    //$("div:contains('Copyright')").addClass("footer");
    var winheight = $(window).height();
    $("body").attr("id", "body2");
    //$("footer").attr("id", "footerpos");
    $("#body2").height(function () {
        if ($("#body2").height() >= winheight) {
            $("#footerpos,#qlinks").addClass("footer_r");

        }
        else {
            $("#footerpos,#qlinks").addClass("footer_f");
        }
    });



});

//new code count
var a = 0;
$(window).scroll(function () {
    if ($('#counter').offset() != undefined) {
        var oTop = $('#counter').offset().top - window.innerHeight;
        if (a == 0 && $(window).scrollTop() > oTop) {
            $('.counter-value').each(function () {
                var $this = $(this),
                  countTo = $this.attr('data-count');
                $({
                    countNum: $this.text()
                }).animate({
                    countNum: countTo
                },

                  {

                      duration: 4000,
                      easing: 'swing',
                      step: function () {
                          $this.text(Math.floor(this.countNum));
                      },
                      complete: function () {
                          $this.text(this.countNum);
                          //alert('finished');
                      }

                  });
            });
            a = 1;
        }
    }
});



function myFunction(x) {
    if (x.matches) { // If media query matches
        document.getElementById("compName").innerHTML = "ShoppingBridge";
    } else {
        var p = "ShoppingBridge";
        if ($('compName').val() != undefined) {
            document.getElementById("compName").innerHTML = p;
        }
    }
}

var x = window.matchMedia("(max-width: 1100px)")
myFunction(x) // Call listener function at run time
x.addListener(myFunction) // Attach listener function on state changes













