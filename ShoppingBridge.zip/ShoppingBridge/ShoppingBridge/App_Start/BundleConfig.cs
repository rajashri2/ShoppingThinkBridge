﻿using System.Web;
using System.Web.Optimization;

namespace ShoppingBridge
{
    public class BundleConfig
    {
        // For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery")
            .Include("~/jq/jquery-{version}.min.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                     "~/Scripts/jquery.validate.min.js",
                     "~/Scripts/jquery.validate.unobtrusive.js",
                     "~/Scripts/jquery.validate.unobtrusive.bootstrap.js"));


            bundles.Add(new StyleBundle("~/bundles/styles").Include(
              "~/Content/styles/bootstrap.css",
              "~/Content/styles/customstyles.css",
              "~/Content/styles/all.css",
              "~/Content/styles/owl.carousel.css",
              "~/Content/styles/Datatable/dataTables.bootstrap4.min.css",
              "~/Content/styles/Datatable/autoFill.bootstrap4.min.css",
              "~/Content/styles/Datatable/buttons.bootstrap4.min.css",

              "~/Content/styles/Datatable/fixedHeader.bootstrap4.min.css",
              "~/Content/styles/Datatable/responsive.bootstrap4.min.css",
              "~/Content/styles/Datatable/scroller.bootstrap4.min.css",
              "~/Content/styles/Datatable/searchPanes.bootstrap4.min.css",
              "~/Content/styles/Datatable/select.bootstrap4.min.css"

              ));

            bundles.Add(new ScriptBundle("~/bundles/scripts").Include(


                       "~/Scripts/bootstrap.js",
                        "~/Scripts/all.js",
                        "~/Scripts/owl.carousel.js",
                         "~/Scripts/Datatable/datatables.min.js",
                         "~/Scripts/Datatable/dataTables.bootstrap4.min.js",
                        "~/Scripts/Datatable/autoFill.bootstrap4.min.js",
             "~/Scripts/Datatable/buttons.bootstrap4.min.js",

             "~/Scripts/Datatable/fixedHeader.bootstrap4.min.js",
             "~/Scripts/Datatable/responsive.bootstrap4.min.js",
             "~/Scripts/Datatable/scroller.bootstrap4.min.js",
             "~/Scripts/Datatable/searchPanes.bootstrap4.min.js",
             "~/Scripts/Datatable/select.bootstrap4.min.js",
             "~/Scripts/customscript.js"

               ));

            BundleTable.EnableOptimizations = true;
        }
    }
}