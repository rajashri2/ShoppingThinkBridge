﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ShoppingBridgeWeb.Models
{
    public class ProductModel
    {
        public Bridge_GetProductDetails ObjProductDetail { get; set; }
        [Required(ErrorMessage = "Please Select file.")]
        [RegularExpression(@"([a-zA-Z0-9\s_\\.\-:])+(.png|.jpg|.jpeg|.gif)$", ErrorMessage = "Only Image files are allowed.")]
        public HttpPostedFileBase UploadFile { get; set; }
    }


    public class Bridge_GetProductDetails
    {
        public int ProductId { get; set; }
        [Required(ErrorMessage = "Product Name is Required")]
        public string P_Name { get; set; }
        [Required(ErrorMessage = "Colour is Required")]
        public string Colour { get; set; }
        public string Dimensions { get; set; }
        [Required(ErrorMessage = "Description is Required")]
        public string Description { get; set; }
        [Required(ErrorMessage = "Please Select Price")]
        public Nullable<int> Price { get; set; }
        [Required(ErrorMessage = "Please Enter ModelNo")]
        public string ModelNo { get; set; }
        [Required(ErrorMessage = "Please Select Memory")]
        public string Storage { get; set; }
        [Required(ErrorMessage = "Please Select Warrenty")]
        public Nullable<int> Warrenty { get; set; }
        [Required(ErrorMessage = "Please Enter Operating System")]
        public string OperatingSystem { get; set; }
        [Required(ErrorMessage = "Please Select Sim Type")]
        public string SimType { get; set; }
        [Required(ErrorMessage = "Please Select Weight")]
        public string Weight { get; set; }
        public string Camera { get; set; }
        public Nullable<System.DateTime> EntryDate { get; set; }
        public Nullable<System.DateTime> ModifiedDate { get; set; }
        [Required(ErrorMessage = "Please Select Brand Name")]
        public string Brand_Name { get; set; }
        public byte[] Image { get; set; }
        public string Flag { get; set; }

    }
    public class CartModel
    {

        public int ProductId { get; set; }
        public string Colour { get; set; }
        public string Dimensions { get; set; }
        public string Description { get; set; }
        public Nullable<int> Price { get; set; }
        public string ModelNo { get; set; }
        public string Storage { get; set; }
        public Nullable<int> Warrenty { get; set; }
        public string OperatingSystem { get; set; }
        public string SimType { get; set; }
        public string Weight { get; set; }
        public string Camera { get; set; }
        public Nullable<System.DateTime> EntryDate { get; set; }
        public Nullable<System.DateTime> ModifiedDate { get; set; }
        public string Brand_Name { get; set; }
        public byte[] Image { get; set; }
        public string Flag { get; set; }


    }
}