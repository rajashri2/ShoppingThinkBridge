﻿using ShoppingBridgeWeb.Common;
using ShoppingBridgeWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Http;
using System.Web.Mvc;
using Newtonsoft.Json;

namespace ShoppingBridgeWeb.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Home()
        {
            List<Bridge_GetProductDetails> lobjProductModel = new List<Bridge_GetProductDetails>();
            using (var Client = WebApiConnection.getApiConnect())
            {
                var response = Client.GetAsync("api/ProductApi/GetProductDetails").Result;
                var result = response.Content.ReadAsAsync<List<Bridge_GetProductDetails>>().Result;
                lobjProductModel = result.ToList();
            }
            return View(lobjProductModel);
        }

        public ActionResult Details(int ProductId)
        {

            ProductModel lobjProductModel = new ProductModel();
            lobjProductModel.ObjProductDetail = new Bridge_GetProductDetails();
            Bridge_GetProductDetails lBridge_GetProductDetails = new Bridge_GetProductDetails();
            using (var Client = WebApiConnection.getApiConnect())
            {
                var response = Client.GetAsync("api/ProductApi/GetProductDetails").Result;
                var result = response.Content.ReadAsAsync<List<Bridge_GetProductDetails>>().Result;
                lBridge_GetProductDetails = result.Where(x => x.ProductId == ProductId).FirstOrDefault();
                var jsonModel = JsonConvert.SerializeObject(lBridge_GetProductDetails);
            }
            lobjProductModel.ObjProductDetail = lBridge_GetProductDetails;
            return View(lobjProductModel);
        }
        public ActionResult CartDetails()
        {

            CartModel objCart = new CartModel();

            return View();
        }

        public ActionResult AboutUs()
        {
            return View();
        }

    }
}
