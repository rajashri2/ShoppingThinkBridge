﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShoppingBridgeWeb.Models;
using ShoppingBridgeWeb.Common;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.IO;

namespace ShoppingBridgeWeb.Controllers
{
    [UserRoleProvider(Roles = "Admin")]
    public class ProductController : Controller
    {

        [UserRoleProvider(Roles = "Admin")]
        public ActionResult Index()
        {
            List<Bridge_GetProductDetails> lobjProductModel = new List<Bridge_GetProductDetails>();
            using (var Client = WebApiConnection.getApiConnect())
            {
                var response = Client.GetAsync("api/ProductApi/GetProductDetails").Result;
                var result = response.Content.ReadAsAsync<List<Bridge_GetProductDetails>>().Result;
                lobjProductModel = result.ToList();
            }
            return View(lobjProductModel);
        }

        [UserRoleProvider(Roles = "Admin")]
        public ActionResult Create()
        {
            ViewBag.PriceList = new SelectList(ProductPrice());
            ViewBag.WeightList = new SelectList(WeightLlist());
            ViewBag.BrandList = new SelectList(BrandList());
            ViewBag.ColourList = new SelectList(ColourList());

            return View();
        }
        public ActionResult Create1()
        {
            ViewBag.PriceList = new SelectList(ProductPrice());
            ViewBag.WeightList = new SelectList(WeightLlist());
            ViewBag.BrandList = new SelectList(BrandList());
            ViewBag.ColourList = new SelectList(ColourList());
            return View();
        }
       

        private List<string> WeightLlist()
        {
            List<string> WeightLlist = new List<string>();
            int start = 150;
            for (int i = 0; i < 15; i++)
            {
                WeightLlist.Add((start + i).ToString() + "gm");
            }
            return WeightLlist;
        }

        private List<string> ProductPrice()
        {
            List<string> pricelist = new List<string>();
            int start = 10000;
            int counter = 1000;
            pricelist.Add(start.ToString());
            for (int i = 1; i <= 50; i++)
            {
                pricelist.Add((start + (counter * i)).ToString());
            }
            return pricelist;
        }

        private List<string> BrandList()
        {
            List<string> BrandList = new List<string>();
            BrandList.Add("Apple");
            BrandList.Add("Blackberry");
            BrandList.Add("Lenovo");
            BrandList.Add("Mi");
            BrandList.Add("Apple");
            BrandList.Add("Oppo");
            BrandList.Add("POCO");
            BrandList.Add("Realme");
            BrandList.Add("Samsung");
            return BrandList;
        }
        private List<string> ColourList()
        {
            List<string> ColourList = new List<string>();
            ColourList.Add("Red");
            ColourList.Add("Black");
            ColourList.Add("Blue");
            ColourList.Add("Gray");
            ColourList.Add("Teal Green");
            ColourList.Add("Rose Gold");
            return ColourList;
        }

        //[UserRoleProvider(Roles = "Admin")]
        //   [HttpPost]
        public ActionResult Update(int ProductId)
        {
            ViewBag.BrandList = new SelectList(BrandList());
            ViewBag.PriceList = new SelectList(ProductPrice());
            ViewBag.WeightList = new SelectList(WeightLlist());
            ViewBag.ColourList = new SelectList(ColourList());

            ProductModel lobjProductModel = new ProductModel();
            lobjProductModel.ObjProductDetail = new Bridge_GetProductDetails();
            Bridge_GetProductDetails lBridge_GetProductDetails = new Bridge_GetProductDetails();
            using (var Client = WebApiConnection.getApiConnect())
            {
                var response = Client.GetAsync("api/ProductApi/GetProductDetails").Result;
                var result = response.Content.ReadAsAsync<List<Bridge_GetProductDetails>>().Result;
                lBridge_GetProductDetails = result.Where(x => x.ProductId == ProductId).FirstOrDefault();
                var jsonModel = JsonConvert.SerializeObject(lBridge_GetProductDetails);
            }
            lobjProductModel.ObjProductDetail = lBridge_GetProductDetails;
            return View("Create", lobjProductModel);
        }

        //  [UserRoleProvider(Roles = "Admin")]
        //[HttpPost]
        //public ActionResult AddEditProduct(string command, ProductModel model)
        //{
        //    if (command == "Edit")
        //    {
        //        model.ObjProductDetail.Flag = "Update";
        //        using (var Client = WebApiConnection.getApiConnect())
        //        {
        //            var jsonModel = JsonConvert.SerializeObject(model.ObjProductDetail);
        //            var content = new StringContent(jsonModel, Encoding.UTF8, "application/json");
        //            var response = Client.PostAsync("api/ProductApi/AddEditProduct", content).Result;
        //            var result = response.Content.ReadAsAsync<ResponseStatus>().Result;
        //        }
        //    }

        //    else//    if (command == "Add")
        //    {
        //        model.ObjProductDetail.Flag = "Insert";
        //        if (model.UploadFile != null && model.UploadFile.ContentLength > 0)
        //        {
        //            byte[] fileInBytes = new byte[model.UploadFile.ContentLength];
        //            using (BinaryReader theReader = new BinaryReader(model.UploadFile.InputStream))
        //            {
        //                fileInBytes = theReader.ReadBytes(model.UploadFile.ContentLength);
        //            }
        //            model.ObjProductDetail.Image = fileInBytes;
        //        }
        //        using (var Client = WebApiConnection.getApiConnect())
        //        {
        //            var jsonModel = JsonConvert.SerializeObject(model.ObjProductDetail);
        //            var content = new StringContent(jsonModel, Encoding.UTF8, "application/json");
        //            var response = Client.PostAsync("api/ProductApi/AddEditProduct", content).Result;
        //            var result = response.Content.ReadAsAsync<ResponseStatus>().Result;
        //            TempData["Message"] = result.Message;
        //        }
        //    }
        //    return RedirectToAction("Index");
        //}



        [HttpPost]
        public ActionResult AddEditProduct(ProductModel model)
        {
            if (model != null && model.ObjProductDetail != null && String.IsNullOrEmpty(model.ObjProductDetail.ProductId.ToString()))
            {
                model.ObjProductDetail.Flag = "Update";
                using (var Client = WebApiConnection.getApiConnect())
                {
                    var jsonModel = JsonConvert.SerializeObject(model.ObjProductDetail);
                    var content = new StringContent(jsonModel, Encoding.UTF8, "application/json");
                    var response = Client.PostAsync("api/ProductApi/AddEditProduct", content).Result;
                    var result = response.Content.ReadAsAsync<ResponseStatus>().Result;
                }
            }

            else
            {
                model.ObjProductDetail.Flag = "Insert";
                if (model.UploadFile != null && model.UploadFile.ContentLength > 0)
                {
                    byte[] fileInBytes = new byte[model.UploadFile.ContentLength];
                    using (BinaryReader theReader = new BinaryReader(model.UploadFile.InputStream))
                    {
                        fileInBytes = theReader.ReadBytes(model.UploadFile.ContentLength);
                    }
                    model.ObjProductDetail.Image = fileInBytes;
                }
                using (var Client = WebApiConnection.getApiConnect())
                {
                    var jsonModel = JsonConvert.SerializeObject(model.ObjProductDetail);
                    var content = new StringContent(jsonModel, Encoding.UTF8, "application/json");
                    var response = Client.PostAsync("api/ProductApi/AddEditProduct", content).Result;
                    var result = response.Content.ReadAsAsync<ResponseStatus>().Result;
                    TempData["Message"] = result.Message;
                }
            }
            return RedirectToAction("Index");
        }
        public ActionResult Delete(int ProductId)
        {
            ProductModel model = new ProductModel();
            model.ObjProductDetail = new Bridge_GetProductDetails();
            model.ObjProductDetail.ProductId = ProductId;
            model.ObjProductDetail.Flag = "Delete";
            using (var Client = WebApiConnection.getApiConnect())
            {
                var jsonModel = JsonConvert.SerializeObject(model.ObjProductDetail);
                var content = new StringContent(jsonModel, Encoding.UTF8, "application/json");
                var response = Client.PostAsync("api/ProductApi/AddEditProduct", content).Result;
                var result = response.Content.ReadAsAsync<ResponseStatus>().Result;
            }
            return RedirectToAction("Index");
        }
    }
}
