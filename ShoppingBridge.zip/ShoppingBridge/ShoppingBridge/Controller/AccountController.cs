﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShoppingBridgeWeb.Models;
using ShoppingBridgeWeb.Common;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Web.Security;

namespace ShoppingBridgeWeb.Controllers
{
    public class AccountController : Controller
    {
        private static string uri = System.Configuration.ConfigurationManager.AppSettings["CommonApiUrl"];
        private static string Accountapi = "api/AccountApi/";

        //
        // GET: /Login/

        public ActionResult Login()
        {
            if (TempData["Message"] != null)
            {
                ViewBag.Message = Convert.ToString(TempData["Message"]);
            }
            return View();
        }
        [HttpPost]
        public ActionResult Login(string UserName, string Password)
        {

            if (!this.ModelState.IsValid)
            {
                return this.View();
            }
            using (var Client = WebApiConnection.getApiConnect())
            {
                var response1 = Client.GetAsync("api/AccountApi/UserDetails?UserName=" + UserName + "&Password=" + Password).Result;
                var result1 = response1.Content.ReadAsAsync<AccountModel>().Result;
                if (result1 != null)
                {
                    this.Session["LoggedUserInfo"] = result1;
                    Session["UserId"] = result1.UserID;
                    Session["UserName"] = result1.UserName;
                    return RedirectToAction("Home", "Home");
                }
                else
                {
                    this.ModelState.AddModelError(string.Empty, "The Username or Password is incorrect.");
                    return this.View();
                }
            }
        }

        public ActionResult LogOut()
        {
            if (Session["UserName"] != null)
            {
                Session["UserName"] = null;
            }
            //var loggedInuserInfo = httpContext.Session["LoggedUserInfo"] as AccountModel;
            //if (loggedInuserInfo == null)
            //{
            //    return false;
            //}

            FormsAuthentication.SignOut();
            Session.Abandon();
            return RedirectToAction("Login", "Account");
        }


        public ActionResult Register()
        {
            return PartialView("_RegisterPartialView");
        }

        [HttpPost]
        public ActionResult AddUser(AccountModel model)
        {
            using (var Client = WebApiConnection.getApiConnect())
            {
                var jsonModel = JsonConvert.SerializeObject(model);
                var content = new StringContent(jsonModel, Encoding.UTF8, "application/json");
                var response = Client.PostAsync(uri + Accountapi, content).Result;
                var result = response.Content.ReadAsAsync<ResponseStatus>().Result;
                TempData["Message"] = result.Message;
                if (result.Status == true)
                {
                    Session["UserName"] = model.UserName;
                }
            }
            return RedirectToAction("Login");
        }
    }
}
