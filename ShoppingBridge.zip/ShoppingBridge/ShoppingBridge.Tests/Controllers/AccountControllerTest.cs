﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ShoppingBridge;
using ShoppingBridgeWeb.Controllers;
using ShoppingBridgeWeb.Models;
using System.Web;

namespace ShoppingBridge.Tests.Controllers
{
    [TestClass]
    public class AccountControllerTest
    {
        //[TestMethod]
        //public void LoginTest()
        //{

        //    AccountController controller = new AccountController();
        //    AccountModel logonModel = new AccountModel();
        //    logonModel.UserName = "admin";
        //    logonModel.Password = "admin";
        //    ViewResult result = controller.Login(logonModel.UserName, logonModel.Password) as ViewResult;
        //    Assert.IsNotNull(result);

        //}
    }
}
