﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ShoppingBridge;
using ShoppingBridgeWeb.Controllers;
using System.Reflection;
using System.Net.Http;

namespace ShoppingBridge.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {

        //[TestMethod]
        //public void Home_Test()
        //{
        //    // Arrange
        //    HomeController controller = new HomeController();
        //    controller.Request = new HttpRequestMessage { RequestUri = new Uri("http://localhost/api/AccountApi/AddUser") };
        //    controller.Configuration = new HttpConfiguration();
        //    controller.Configuration.Routes.MapHttpRoute(
        //        name: "DefaultApi",
        //        routeTemplate: "api/{controller}/{id}",
        //        defaults: new { id = RouteParameter.Optional });
        //    // Act
        //    ViewResult result = controller.Home() as ViewResult;

        //    // Assert
        //    Assert.IsNotNull(result);
        //}

        //[Test]
        //[TestCase("Index", "Index")]
        //[TestCase("Create", "Create")]
        [TestMethod]
        public void TestExpectedViewIsReturned(string expectedViewName, string controllerMethodName)
        {
            ViewResult result = GetViewResult(new HomeController(), controllerMethodName);

            Assert.AreEqual(expectedViewName, result.ViewName, "Unexpected view returned, controller: {0}, view: {1}", controllerMethodName, expectedViewName);
        }

        private ViewResult GetViewResult(Controller controller, string controllerMethodName)
        {
            Type type = controller.GetType();
            ConstructorInfo constructor = type.GetConstructor(Type.EmptyTypes);

            object instance = constructor.Invoke(new object[] { });
            MethodInfo[] methods = type.GetMethods();

            MethodInfo methodInfo = (from method in methods
                                     where method.Name == controllerMethodName
                                                         && method.GetParameters().Count() == 0
                                     select method).FirstOrDefault();

            Assert.IsNotNull(methodInfo, "The controller {0} has no method called {1}", type.Name, controllerMethodName);

            ViewResult result = methodInfo.Invoke(instance, new object[] { }) as ViewResult;

            Assert.IsNotNull(result, "The ViewResult is null, controller: {0}, view: {1}", type.Name, controllerMethodName);

            return result;
        }


    }
}
